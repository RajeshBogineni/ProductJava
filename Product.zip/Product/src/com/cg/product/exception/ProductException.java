package com.cg.product.exception;

public class ProductException extends Exception{

	public ProductException(String excep) {
		super();
		System.out.println(excep);
	}
			
	
}
