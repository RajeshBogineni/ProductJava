package com.cg.product.pl;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.xml.ws.ServiceMode;

import com.cg.product.bean.Customer;
import com.cg.product.bean.Products;
import com.cg.product.exception.ProductException;
import com.cg.product.service.ProductService;
import com.cg.product.service.ProductServiceImpl;

public class ProductMain {
	static Scanner sc=new Scanner(System.in);
	static ProductService productService=null;
	static ProductServiceImpl productServiceimpl=null;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer customer=null;
		Products products=null;
		
		
		int option;
		while(true)
		{
			
			System.out.println("PRODUCTS IN SHOP");
			System.out.println("____________");
			System.out.println("1.PURCHASE PRODUCT");
			System.out.println("2.SEARCH PRODUCT");
			System.out.println("3.VIEW PRODUCTS");
			System.out.println("4.EXIT");
			System.out.println("______________");
			System.out.println("ENTER YOUR OPTION");
			
			option=sc.nextInt();
			switch(option)
			{
			case 1:
				
				try {
					
					
					while(customer==null)
					{
					customer=customerDetails();
					}
					while(products==null)
					{
					products=ProductMain.products();
					}
					productService=new ProductServiceImpl();
					try {
						productService.buyProduct(customer,products);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					
				} 
				catch (ProductException e) {
					
				}
				
				
				break;
				
			case 2:
				productServiceimpl=new ProductServiceImpl();
				System.out.println("Product Name :");
				String productName=sc.next();
				System.out.println("Model No :");
				String modelNo=sc.next();
				try {
					System.out.println("products "+productServiceimpl.searchProduct(productName,modelNo));
					
				}
				catch (Exception e) {
					System.out.println("No Product Found.");
				} 
				
				break;
				
			case 3:
				List<Products> li=new ArrayList<Products>();
				productServiceimpl=new ProductServiceImpl();
				li=productServiceimpl.showStock();
				System.out.println(li+"\n");
				
				break;
				
			case 4:
				
				System.exit(0);
				break;
				
			}
		}
		

	}
	
	public static Customer customerDetails() throws ProductException
	{
		Customer customer=new Customer();
		System.out.println("Enter Customer Details");
		System.out.println("Enter Customer Name :");
		customer.setcName(sc.next());
		
		System.out.println("Enter Phone Name :");
		customer.setPhoneNo(sc.next());
		
		System.out.println("Enter email Id :");
		customer.setEmail(sc.next());
		
		try
		{
			productServiceimpl=new ProductServiceImpl();
			productServiceimpl.validation(customer);
			return customer;
		}
		catch(Exception e)
		{
			System.out.println("\n enter valid Deatails \n"+"try agian");
		}
		return null;
	}
	public static Products products() throws ProductException
	{
		Products product=new Products();
		System.out.println("Enter Product details you want :");
		System.out.println("Enter Product Name :");
		product.setProductname(sc.next());
		
		System.out.println("Enter Model No");
		product.setModelNo(sc.next());
		try
		{
				productServiceimpl.productValidation(product);
				return product;
		}
		catch(ProductException e)
		{
			
		}
		return null;
	}

}
