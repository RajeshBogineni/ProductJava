package com.cg.product.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.product.bean.Customer;
import com.cg.product.bean.Products;
import com.cg.product.dao.ProductDAO;
import com.cg.product.dao.ProductDAOImpl;
import com.cg.product.exception.ProductException;

public class ProductServiceImpl implements ProductService{
		ProductDAO mDAO=new ProductDAOImpl();
	public void buyProduct(Customer customer,Products product) throws Exception {
		System.out.println("In service");
		mDAO.buyProduct(customer,product);
		
	}

	public Products searchProduct(String productname,String modelno) throws Exception {
		
		Products product=new Products();
		String name=productname;
		String no=modelno;
		product=mDAO.searchProduct(name,no);
		return product;
	}

	public List showStock() {
		List<Products> li=new ArrayList<Products>();
		li=mDAO.showStock();
		
		return li;
	}
	
	
	public void validation(Customer customer) throws ProductException
	 {
		
		List validationerrors=new ArrayList();
		if(!isValidName(customer.getcName()))
		{
					validationerrors.add("Name should be minium of 3 characters");
		}
		if(!isValidEmail(customer.getEmail()))
		{
					validationerrors.add("Enter a valid email Id");
		}
		if(!isValidPhone(customer.getPhoneNo()))
		{
					validationerrors.add("Number should be only digits and 10 in length");
		}
		if(!validationerrors.isEmpty())
		{
					throw new ProductException(validationerrors+"\n");
		}
		
	}
	
	public void productValidation(Products product) throws ProductException
	{
		
		List validationerror=new ArrayList();
		if(!isValidProduct(product.getProductname()))
		{
			validationerror.add("product not available");
		}
		if(!validationerror.isEmpty())
		{
			throw new ProductException(validationerror+"\n");
		}
		
	}
	
	
	
	public boolean isValidName(String cname)
	{
		Pattern p=Pattern.compile("[A-Z][a-z]{3,}");
		Matcher m=p.matcher(cname);
		return m.matches();
	}
	public boolean isValidPhone(String phone)
	{
		Pattern p=Pattern.compile("[6-9][0-9]{9}");
		Matcher m=p.matcher(phone);
		return m.matches();
	}
	public boolean isValidEmail(String email)
	{
		Pattern p=Pattern.compile("^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$");
		Matcher m=p.matcher(email);
		return m.matches();
	}
	public boolean isValidProduct(String product)
	{
		String product1=product;
		
		if(product1.equals("Ac")||product1.equals("fridge")||product1.equals("washing")||product1.equals("dining"))
		{
			
			return true;
		}
		else
		{
			return false;
		}
				
	}
	
}
