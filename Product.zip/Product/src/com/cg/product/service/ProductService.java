package com.cg.product.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.product.bean.Customer;
import com.cg.product.bean.Products;

public interface ProductService {
		
	public void buyProduct(Customer customer,Products product) throws Exception;
	public Products searchProduct(String name,String modelno) throws Exception;
	public List showStock();
	
	
}
