package com.cg.product.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.product.bean.Customer;
import com.cg.product.bean.Products;

public interface ProductDAO {

	public void buyProduct(Customer customer,Products product) throws Exception;
	public Products searchProduct(String productname,String modelno) throws  Exception;
	public List showStock();
}
