package com.cg.product.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.product.bean.Customer;
import com.cg.product.bean.Products;
import com.cg.product.util.DBConnection;

public class ProductDAOImpl implements ProductDAO {

	@Override
	public void buyProduct(Customer customer,Products product) throws Exception {
		
		
		String modelno=product.getModelNo();
		String productname=product.getProductname();
		System.out.println(modelno);
		System.out.println(customer.getcName());
		Connection connection=null;
		try
		{
		connection=DBConnection.getConnection();
		
		PreparedStatement pS=connection.prepareStatement("insert into customer values(?,?,?,?,?,sysdate,id.nextval)");
		pS.setString(1,customer.getcName());
		pS.setString(2,customer.getEmail());
		pS.setString(3,customer.getPhoneNo());
		pS.setString(4,productname);
		pS.setString(5,modelno);
		pS.executeUpdate();
		
		Statement s=connection.createStatement();
		s.executeUpdate("update products set quantity=quantity-1 where modelno='"+modelno+"' and productname='"+productname+"'");
		connection.close();
		}
		
		catch(Exception e)
		{
			
		}
	}

	@Override
	public Products searchProduct(String productname,String modelno) throws Exception {
		// TODO Auto-generated method stub
		String productName=productname;
		String modelNo=modelno;
		
		Products product=new Products();
		try
		{
		Connection connection=null;
		connection=DBConnection.getConnection();
		
		Statement s=connection.createStatement();
		ResultSet rS=s.executeQuery("select * from products where modelno='"+modelNo+"' and productname='"+productName+"'");
		
		while(rS.next())
		{
			
			String n=rS.getString(1);
			String n1=rS.getString(2);
			int a=rS.getInt(3);
			String b=rS.getString(4);
			product.setProductname(n1);
			product.setModelNo(n);
			product.setbrand(b);
			product.setQuantity(a);
		}
		connection.close();
		}
		
		catch(Exception s)
		{
			s.printStackTrace();
		}
		return product;
	}

	@Override
	public List showStock() {
		List<Products> li=new ArrayList<Products>();
		
		try
		{
		Connection connection=null;
		connection=DBConnection.getConnection();
		
		Statement s=connection.createStatement();
		ResultSet rS=s.executeQuery("select * from Products");
		
		while(rS.next())
		{
			Products product=new Products();
			product.setModelNo(rS.getString(1));
			product.setProductname(rS.getString(2));
			product.setbrand(rS.getString(4));
			
			li.add(product);	
			
		}
		connection.close();
		}
		
		catch(Exception s)
		{
			s.printStackTrace();
		}

		return li;
	}

}
