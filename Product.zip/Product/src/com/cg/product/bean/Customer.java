package com.cg.product.bean;

import java.util.Date;

public class Customer {
	
	public String cName;
	public String phoneNo;
	public String email;
	public Date purchase;
	public String Cid;
	public String getCid() {
		return Cid;
	}
	public void setCid(String cid) {
		Cid = cid;
	}
	
	public Date getPurchase() {
		return purchase;
	}
	public void setPurchase(Date purchase) {
		this.purchase = purchase;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Customer [cName=" + cName + ", phoneNo=" + phoneNo + ", email=" + email + ", purchase=" + purchase + ", Cid=" + Cid + "]";
	}
	
	
}
