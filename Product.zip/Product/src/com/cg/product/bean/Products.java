package com.cg.product.bean;

public class Products {
	
	public String productname;
	public String modelNo;
	public String brand;
	public int quantity;
	
	
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public String getModelNo() {
		return modelNo;
	}
	public void setModelNo(String modelNo) {
		this.modelNo = modelNo;
	}
	public String getbrand() {
		return brand;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public void setbrand(String oS) {
		this.brand = brand;
	}
	
	
	
	@Override
	public String toString() {
		return "Products [productname=" + productname + ", modelNo=" + modelNo + ", brand=" + brand + ", quantity=" + quantity + "] \n";
	}	
	

}
